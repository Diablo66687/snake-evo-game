using System;
using System.Collections.Generic;
using Xunit;
using ConsoleApp2;

namespace ConsoleApp2.Tests
{
    public class FoodTests
    {
        [Fact]
        public void GenerateFood_ReturnsValidPosition()
        {
            var snake = new List<(int x, int y)> { (1, 1), (2, 2) };
            var obstacles = new List<(int x, int y)> { (3, 3) };
            var snake2 = new List<(int x, int y)> { (4, 4) };
            var pos = Program.GenerateFood(snake, obstacles, snake2, 10, 10);
            Assert.DoesNotContain(pos, snake);
            Assert.DoesNotContain(pos, obstacles);
            Assert.DoesNotContain(pos, snake2);
            Assert.InRange(pos.x, 0, 9);
            Assert.InRange(pos.y, 0, 9);
        }
    }
}
