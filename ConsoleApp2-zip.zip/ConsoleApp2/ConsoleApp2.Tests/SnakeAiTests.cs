using System;
using Xunit;
using System.Collections.Generic;

namespace ConsoleApp2.Tests
{
    public class SnakeAiTests
    {
        [Fact]
        public void FindPathLength_ReturnsZero_WhenStartIsGoal()
        {
            var snake = new List<(int x, int y)>();
            var snake2 = new List<(int x, int y)>();
            var obstacles = new List<(int x, int y)>();
            int result = Program.FindPathLength((1, 1), (1, 1), snake2, snake, obstacles, 3);
            Assert.Equal(0, result);
        }

        [Fact]
        public void FindPathLength_ReturnsMinusOne_WhenBlocked()
        {
            var snake = new List<(int x, int y)>();
            var snake2 = new List<(int x, int y)>();
            var obstacles = new List<(int x, int y)> { (2, 1), (1, 2), (0, 1), (1, 0) };
            int result = Program.FindPathLength((1, 1), (2, 2), snake2, snake, obstacles, 3);
            Assert.Equal(-1, result);
        }

        [Fact]
        public void FindPathLength_ReturnsCorrectLength_WhenPathExists()
        {
            var snake = new List<(int x, int y)>();
            var snake2 = new List<(int x, int y)>();
            var obstacles = new List<(int x, int y)>();
            int result = Program.FindPathLength((1, 1), (3, 1), snake2, snake, obstacles, 3);
            Assert.Equal(2, result);
        }
    }
}
