﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using SharpDX.XInput;
using Spectre.Console;

namespace ConsoleApp2
{
    public class Program
    {
        enum FoodType { Normal, DoublePoints, Slow, Shorten, Invisible, Reverse, Long }
        static int invisibleTicks = 0;
        static int reverseTicks = 0;

        private static int width = 80;
        private static int height = 40;
        private static List<(int x, int y)> snake = new List<(int x, int y)>();
        private static (int x, int y) food;
        private static FoodType foodType;
        private static int dx = 1, dy = 0;
        private static readonly Random rnd = new Random();
        private static int score = 0;
        private static int highscore = 0;
        private static string highscoreFile = "highscore.txt";
        private static int speed = 100;
        private static bool paused = false;
        private static List<(int x, int y)> obstacles = new List<(int x, int y)>();
        private static int selectedLevel = 1;
        private static int playerCount = 1;
        private static List<(int x, int y)> snake2 = new List<(int x, int y)>();
        private static int dx2 = 0, dy2 = 0;
        private static int score2 = 0;
        private static string gameLogFile = "gamelog.txt";
        private static bool gameLogEnabled = false;
        private static string selectedLanguage = "en";
        private static readonly string[] supportedLanguages = { "cs", "en", "de", "es", "pl", "uk" };
        private static readonly Dictionary<string, Dictionary<string, string>> texts = new()
        {
            ["cs"] = new() {
                ["menu_title"] = "SNAKE EVOLUTION - MENU",
                ["devbrain"] = "DevBrain ©",
                ["start"] = "1 - Spustit hru",
                ["highscore"] = "2 - Zobrazit rekordy",
                ["level"] = "3 - Úroveň (aktuální: {0})",
                ["players"] = "4 - Hráči (aktuální: {0})",
                ["log"] = "5 - Herní log {0}",
                ["lang"] = "6 - Jazyk (aktuální: {0})",
                ["howto"] = "7 - Jak hrát",
                ["exit"] = "Esc/Enter - Ukončit",
                ["score"] = "Skóre: {0}   Rekord: {1}   Délka hada: {2}",
                ["score2"] = "Skóre hráče 2: {0}   Délka hada 2: {1}",
                ["pause"] = "--- PAUZA ---",
                ["restart"] = "Stiskni R pro restart nebo Esc/Enter pro ukončení...",
                ["gameover1"] = "Konec hry! Skóre hráče 1: {0}",
                ["gameover2"] = "Konec hry! Skóre hráče 2: {0}",
                ["newrecord"] = "Nový rekord hráce 1!",
                ["highscore_val"] = "Rekord: {0}",
                ["press_any"] = "Stiskni libovolnou klávesu...",
                ["log_on"] = "(zapnuto)",
                ["log_off"] = "(vypnuto)",
                ["howto_text"] = "Ovládání:",
                ["howto_text2"] = "Hráč 1: šipky nebo WASD\\nHráč 2: IJKL\\nP - pauza\\nR - restart\\nEsc/Enter - ukončení\\n\\nCíl: Sněz co nejvíce jídla, vyhýbej se překážkám a sobě.\nSpeciální jídla: $ = +2 body, S = zpomalení, - = zkrácení hada.",
                ["choice_prompt"] = "Zadej číslo volby a potvrď Enterem: ",
            },
            ["en"] = new() {
                ["menu_title"] = "SNAKE EVOLUTION - MENU",
                ["devbrain"] = "DevBrain ©",
                ["start"] = "1 - Start game",
                ["highscore"] = "2 - Show highscores",
                ["level"] = "3 - Level (current: {0})",
                ["players"] = "4 - Players (current: {0})",
                ["log"] = "5 - Game log {0}",
                ["lang"] = "6 - Language (current: {0})",
                ["howto"] = "7 - How to play",
                ["exit"] = "Esc/Enter - Exit",
                ["score"] = "Score: {0}   Highscore: {1}   Snake length: {2}",
                ["score2"] = "Player 2 score: {0}   Snake 2 length: {1}",
                ["pause"] = "--- PAUSE ---",
                ["restart"] = "Press R to restart or Esc/Enter to exit...",
                ["gameover1"] = "Game over! Player 1 score: {0}",
                ["gameover2"] = "Game over! Player 2 score: {0}",
                ["newrecord"] = "New record for player 1!",
                ["highscore_val"] = "Highscore: {0}",
                ["press_any"] = "Press any key...",
                ["log_on"] = "(on)",
                ["log_off"] = "(off)",
                ["howto_text"] = "Controls:",
                ["howto_text2"] = "Player 1: arrows or WASD\\nPlayer 2: IJKL\\nP - pause\\nR - restart\\nEsc/Enter - exit\\n\\nGoal: Eat as much food as possible, avoid obstacles and yourself.\\nSpecial food: $ = +2 points, S = slow, - = shorten snake.",
                ["choice_prompt"] = "Enter your choice and press Enter: ",
            },
            ["de"] = new() {
                ["menu_title"] = "SNAKE EVOLUTION - MENÜ",
                ["devbrain"] = "DevBrain ©",
                ["start"] = "1 - Spiel starten",
                ["highscore"] = "2 - Highscores anzeigen",
                ["level"] = "3 - Level (aktuell: {0})",
                ["players"] = "4 - Spieler (aktuell: {0})",
                ["log"] = "5 - Spielprotokoll {0}",
                ["lang"] = "6 - Sprache (aktuell: {0})",
                ["howto"] = "7 - Anleitung",
                ["exit"] = "Esc/Enter - Beenden",
                ["score"] = "Punkte: {0}   Highscore: {1}   Länge: {2}",
                ["score2"] = "Spieler 2 Punkte: {0}   Länge 2: {1}",
                ["pause"] = "--- PAUSE ---",
                ["restart"] = "Drücke R für Neustart oder Esc/Enter für Beenden...",
                ["gameover1"] = "Spiel vorbei! Spieler 1 Punkte: {0}",
                ["gameover2"] = "Spiel vorbei! Spieler 2 Punkte: {0}",
                ["newrecord"] = "Neuer Rekord für Spieler 1!",
                ["highscore_val"] = "Highscore: {0}",
                ["press_any"] = "Beliebige Taste drücken...",
                ["log_on"] = "(an)",
                ["log_off"] = "(aus)",
                ["howto_text"] = "Steuerung:",
                ["howto_text2"] = "Spieler 1: Pfeiltasten nebo WASD\\nSpieler 2: IJKL\\nP - Pause\\nR - Neustart\\nEsc/Enter - Beenden\\n\\nZiel: Iss so viel jako možná, vyhýbej se překážkám a sobě.\\nSpeciální jídla: $ = +2 body, S = zpomalení, - = zkrácení hada.",
                ["choice_prompt"] = "Geben Sie die Nummer ein und drücken Sie Enter: ",
            },
            ["es"] = new() {
                ["menu_title"] = "SNAKE EVOLUTION - MENÚ",
                ["devbrain"] = "DevBrain ©",
                ["start"] = "1 - Iniciar juego",
                ["highscore"] = "2 - Mostrar récords",
                ["level"] = "3 - Nivel (actual: {0})",
                ["players"] = "4 - Jugadores (actual: {0})",
                ["log"] = "5 - Registro de juego {0}",
                ["lang"] = "6 - Idioma (actual: {0})",
                ["howto"] = "7 - Cómo jugar",
                ["exit"] = "Esc/Enter - Salir",
                ["score"] = "Puntuación: {0}   Récord: {1}   Longitud: {2}",
                ["score2"] = "Jugador 2 puntuación: {0}   Longitud 2: {1}",
                ["pause"] = "--- PAUSA ---",
                ["restart"] = "Pulsa R para reiniciar o Esc/Enter para salir...",
                ["gameover1"] = "Fin del juego! Jugador 1 puntuación: {0}",
                ["gameover2"] = "Fin del juego! Jugador 2 puntuación: {0}",
                ["newrecord"] = "Nuevo récord para jugador 1!",
                ["highscore_val"] = "Récord: {0}",
                ["press_any"] = "Pulsa cualquier tecla...",
                ["log_on"] = "(activado)",
                ["log_off"] = "(desactivado)",
                ["howto_text"] = "Controles:",
                ["howto_text2"] = "Jugador 1: flechas o WASD\\nJugador 2: IJKL\\nP - pausa\\nR - reiniciar\\nEsc/Enter - salir\\n\\nObjetivo: Come tanta comida como puedas, evita obstáculos y a ti mismo.\\nComida especial: $ = +2 puntos, S = ralentizar, - = acortar la serpiente.",
                ["choice_prompt"] = "Introduce el número y pulsa Enter: ",
            },
            ["pl"] = new() {
                ["menu_title"] = "SNAKE EVOLUTION - MENU",
                ["devbrain"] = "DevBrain ©",
                ["start"] = "1 - Rozpocznij grę",
                ["highscore"] = "2 - Pokaż najlepsze wyniki",
                ["level"] = "3 - Poziom (aktualny: {0})",
                ["players"] = "4 - Gracze (aktualny: {0})",
                ["log"] = "5 - Dziennik gry {0}",
                ["lang"] = "6 - Język (aktualny: {0})",
                ["howto"] = "7 - Jak grać",
                ["exit"] = "Esc/Enter - Wyjdź",
                ["score"] = "Wynik: {0}   Najlepszy wynik: {1}   Długość węża: {2}",
                ["score2"] = "Wynik gracza 2: {0}   Długość węża 2: {1}",
                ["pause"] = "--- PAUZA ---",
                ["restart"] = "Naciśnij R, aby zrestartować lub Esc/Enter, aby wyjść...",
                ["gameover1"] = "Koniec gry! Wynik gracza 1: {0}",
                ["gameover2"] = "Koniec gry! Wynik gracza 2: {0}",
                ["newrecord"] = "Nowy rekord gracza 1!",
                ["highscore_val"] = "Najlepszy wynik: {0}",
                ["press_any"] = "Naciśnij dowolny klawisz...",
                ["log_on"] = "(włączone)",
                ["log_off"] = "(wyłączone)",
                ["howto_text"] = "Sterowanie:",
                ["howto_text2"] = "Gracz 1: strzałki lub WASD\\nGracz 2: IJKL\\nP - pauza\\nR - restart\\nEsc/Enter - wyjście\\n\\nCel: Zjedz jak najwięcej jedzenia, unikaj przeszkód i siebie samego.\\nSpecjalne jedzenie: $ = +2 punkty, S = spowolnienie, - = skrócenie węża.",
                ["choice_prompt"] = "Wpisz numer i naciśnij Enter: ",
            },
            ["uk"] = new() {
                ["menu_title"] = "SNAKE EVOLUTION - МЕНЮ",
                ["devbrain"] = "DevBrain ©",
                ["start"] = "1 - Розпочати гру",
                ["highscore"] = "2 - Показати рекорди",
                ["level"] = "3 - Рівень (актуальний: {0})",
                ["players"] = "4 - Гравці (актуальний: {0})",
                ["log"] = "5 - Журнал гри {0}",
                ["lang"] = "6 - Мова (актуальна: {0})",
                ["howto"] = "7 - Як грати",
                ["exit"] = "Esc/Enter - Вийти",
                ["score"] = "Рахунок: {0}   Рекорд: {1}   Довжина змії: {2}",
                ["score2"] = "Рахунок гравця 2: {0}   Довжина змії 2: {1}",
                ["pause"] = "--- ПАУЗА ---",
                ["restart"] = "Натисніть R, щоб перезапустити, або Esc/Enter, щоб вийти...",
                ["gameover1"] = "Кінець гри! Рахунок гравця 1: {0}",
                ["gameover2"] = "Кінець гри! Рахунок гравця 2: {0}",
                ["newrecord"] = "Новий рекорд для гравця 1!",
                ["highscore_val"] = "Рекорд: {0}",
                ["press_any"] = "Натисніть будь-яку клавішу...",
                ["log_on"] = "(увімкнено)",
                ["log_off"] = "(вимкнено)",
                ["howto_text"] = "Управління:",
                ["howto_text2"] = "Гравець 1: стрілки або WASD\\nГравець 2: IJKL\\nP - пауза\\nR - перезапустити\\nEsc/Enter - вихід\\n\\nМета: З'їсти якомога більше їжі, уникаючи перешкод і самого себе.\\nСпеціальна їжа: $ = +2 очки, S = уповільнення, - = вкорочення змії.",
                ["choice_prompt"] = "Введіть номер і натисніть Enter: ",
            }
        };

        private static int colorScheme = 0;
        private static readonly int colorSchemeCount = 3;
        private static readonly string[] colorSchemeNames = { "Default", "Retro", "HighContrast" };

        enum GameMode { Single, DuelHuman, DuelAI }
        private static GameMode gameMode = GameMode.Single;

        static void LogError(string message, Exception ex = null)
        {
            try
            {
                using (var sw = new StreamWriter(gameLogFile, true))
                {
                    sw.WriteLine($"[{DateTime.Now}] ERROR: {message}");
                    if (ex != null)
                        sw.WriteLine(ex.ToString());
                }
            }
            catch { /* Pokud selže logování, ignorovat */ }
        }

        static void LoadHighscore()
        {
            try
            {
                if (File.Exists(highscoreFile))
                {
                    string[] lines = File.ReadAllLines(highscoreFile);
                    if (lines.Length > 0)
                        highscore = int.Parse(lines[0]);
                }
            }
            catch (Exception ex)
            {
                LogError("Failed to load highscore.", ex);
                highscore = 0;
            }
        }

        static void SaveHighscore()
        {
            try
            {
                File.WriteAllText(highscoreFile, highscore.ToString());
            }
            catch (Exception ex)
            {
                LogError("Failed to save highscore.", ex);
            }
        }

        static void ShowSpectreLoading(string message = "Načítání hry...")
        {
            AnsiConsole.Clear();
            // Use only a spinner (Status) without nesting Progress
            AnsiConsole.Status()
                .Spinner(Spinner.Known.Dots)
                .SpinnerStyle(Style.Parse("green"))
                .Start(message, ctx =>
                {
                    // Simulate loading with a delay
                    Thread.Sleep(1000);
                });
        }

        static void ShowSpectrePause()
        {
            AnsiConsole.Status()
                .Spinner(Spinner.Known.Star)
                .SpinnerStyle(Style.Parse("yellow"))
                .Start("Pauza...", ctx =>
                {
                    Thread.Sleep(1000);
                });
        }

        static void ShowSpectreLiveScore()
        {
            var table = new Table().Border(TableBorder.Rounded).BorderColor(Color.Grey);
            table.AddColumn("[bold]Player[/]");
            table.AddColumn("[bold]Score[/]");
            table.AddColumn("[bold]Length[/]");
            table.AddRow("1", score.ToString(), snake.Count.ToString());
            if (playerCount == 2)
                table.AddRow("2", score2.ToString(), snake2.Count.ToString());
            AnsiConsole.Live(table)
                .AutoClear(false)
                .Start(ctx =>
                {
                    for (int i = 0; i < 10; i++)
                    {
                        table.Rows.Clear();
                        table.AddRow("1", (score + i).ToString(), snake.Count.ToString());
                        if (playerCount == 2)
                            table.AddRow("2", score2.ToString(), snake2.Count.ToString());
                        ctx.Refresh();
                        Thread.Sleep(100);
                    }
                });
        }

        static void ShowSpectreScoreChart(List<int> scoreHistory)
        {
            var chart = new BarChart()
                .Width(60)
                .Label("Vývoj skóre")
                .CenterLabel();
            for (int i = 0; i < scoreHistory.Count; i++)
            {
                chart.AddItem($"{i+1}", scoreHistory[i], Color.Green);
            }
            AnsiConsole.Write(chart);
            AnsiConsole.MarkupLine("[grey]Stiskni libovolnou klávesu...[/]");
            Console.ReadKey(true);
        }

        static void UpdateGameAreaToWindow()
        {
            // Get current window size
            int winWidth = Console.WindowWidth;
            int winHeight = Console.WindowHeight;
            // Set game area to fit window, leaving space for UI
            width = Math.Max(10, winWidth - 2); // leave border
            height = Math.Max(5, winHeight - 6); // leave space for UI
        }

        static void StartGame()
        {
            ShowSpectreLoading();
            UpdateGameAreaToWindow();
            snake.Clear();
            snake.Add((width / 2, height / 2));
            dx = 1; dy = 0;
            score = 0;
            // Zrychlení hada: nižší hodnoty speed
            switch (selectedLevel)
            {
                case 1:
                    speed = 50; break; // původně 100
                case 2:
                    speed = 35; break; // původně 80
                case 3:
                    speed = 20; break; // původně 60
            }
            invisibleTicks = 0;
            reverseTicks = 0;
            food = GenerateFood(snake, obstacles, snake2, width, height);
            foodType = (FoodType)rnd.Next(0, 7);
            obstacles.Clear();
            int obstacleCount = selectedLevel * 20;
            for (int i = 0; i < obstacleCount; i++)
            {
                (int x, int y) pos;
                do
                {
                    pos = (rnd.Next(width), rnd.Next(height));
                } while (snake.Contains(pos) || obstacles.Contains(pos) || pos == food);
                obstacles.Add(pos);
            }
            Console.SetWindowSize(Math.Min(width + 2, 200), Math.Min(height + 8, 60));
            Console.Clear();
            GameLoop();
        }

        public static (int x, int y) GenerateFood(List<(int x, int y)> snake, List<(int x, int y)> obstacles, List<(int x, int y)> snake2, int width, int height, int maxTries = 1000)
        {
            int tries = 0;
            while (tries < maxTries)
            {
                var pos = (rnd.Next(width), rnd.Next(height));
                if (!snake.Contains(pos) && !obstacles.Contains(pos) && !snake2.Contains(pos))
                    return pos;
                tries++;
            }
            LogError($"Food generation failed after {maxTries} tries.");
            return (0, 0); // fallback
        }

        static void DrawBufferedGame()
        {
            // Create buffer for the game area
            char[,] buffer = new char[width + 2, height + 2];
            ConsoleColor[,] colorBuffer = new ConsoleColor[width + 2, height + 2];
            // Fill with spaces
            for (int y = 0; y < height + 2; y++)
                for (int x = 0; x < width + 2; x++)
                {
                    buffer[x, y] = ' ';
                    colorBuffer[x, y] = ConsoleColor.Black;
                }
            // Border
            for (int x = 0; x < width + 2; x++)
            {
                buffer[x, 0] = buffer[x, height + 1] = '█';
                colorBuffer[x, 0] = colorBuffer[x, height + 1] = ConsoleColor.Gray;
            }
            for (int y = 0; y < height + 2; y++)
            {
                buffer[0, y] = buffer[width + 1, y] = '█';
                colorBuffer[0, y] = colorBuffer[width + 1, y] = ConsoleColor.Gray;
            }
            // Obstacles
            foreach (var obs in obstacles)
            {
                buffer[obs.x + 1, obs.y + 1] = '■';
                colorBuffer[obs.x + 1, obs.y + 1] = ConsoleColor.Red;
            }
            // Snake 1
            if (snake.Count > 0)
            {
                var head = snake[0];
                char headChar = dx == 1 ? '>' : dx == -1 ? '<' : dy == 1 ? 'v' : dy == -1 ? '^' : 'O';
                buffer[head.x + 1, head.y + 1] = headChar;
                colorBuffer[head.x + 1, head.y + 1] = ConsoleColor.Green;
                for (int i = 1; i < snake.Count; i++)
                {
                    var part = snake[i];
                    buffer[part.x + 1, part.y + 1] = '=';
                    colorBuffer[part.x + 1, part.y + 1] = ConsoleColor.DarkGreen;
                }
            }
            // Snake 2
            if (playerCount == 2 && snake2.Count > 0)
            {
                var head2 = snake2[0];
                char headChar2 = dx2 == 1 ? '>' : dx2 == -1 ? '<' : dy2 == 1 ? 'v' : dy2 == -1 ? '^' : 'O';
                buffer[head2.x + 1, head2.y + 1] = headChar2;
                colorBuffer[head2.x + 1, head2.y + 1] = ConsoleColor.Yellow;
                for (int i = 1; i < snake2.Count; i++)
                {
                    var part2 = snake2[i];
                    buffer[part2.x + 1, part2.y + 1] = '=';
                    colorBuffer[part2.x + 1, part2.y + 1] = ConsoleColor.DarkYellow;
                }
            }
            // Food
            buffer[food.x + 1, food.y + 1] = foodType == FoodType.DoublePoints ? '♦' : '●';
            colorBuffer[food.x + 1, food.y + 1] = ConsoleColor.Blue;
            // Render buffer
            Console.SetCursorPosition(0, 0);
            for (int y = 0; y < height + 2; y++)
            {
                for (int x = 0; x < width + 2; x++)
                {
                    Console.ForegroundColor = colorBuffer[x, y];
                    Console.Write(buffer[x, y]);
                }
                Console.WriteLine();
            }
            Console.ResetColor();
            // UI
            Console.SetCursorPosition(0, height + 3);
            Console.Write(texts[selectedLanguage]["score"], score, highscore, snake.Count);
            if (playerCount == 2)
                Console.Write("   " + texts[selectedLanguage]["score2"], score2, snake2.Count);
            Console.SetCursorPosition(0, height + 4);
            Console.WriteLine(texts[selectedLanguage]["pause"]);
            Console.SetCursorPosition(0, height + 5);
            Console.WriteLine(texts[selectedLanguage]["restart"]);
        }

        static void DrawSpectreGame()
        {
            var canvas = new Canvas(width + 2, height + 2);
            // Border
            for (int x = 0; x <= width + 1; x++)
            {
                canvas.SetPixel(x, 0, Color.Grey);
                canvas.SetPixel(x, height + 1, Color.Grey);
            }
            for (int y = 0; y <= height + 1; y++)
            {
                canvas.SetPixel(0, y, Color.Grey);
                canvas.SetPixel(width + 1, y, Color.Grey);
            }
            // Obstacles
            foreach (var obs in obstacles)
                canvas.SetPixel(obs.x + 1, obs.y + 1, Color.Red);
            // Snake 1
            foreach (var part in snake)
                canvas.SetPixel(part.x + 1, part.y + 1, Color.Green);
            // Snake 2
            if (playerCount == 2)
                foreach (var part in snake2)
                    canvas.SetPixel(part.x + 1, part.y + 1, Color.Yellow);
            // Food
            canvas.SetPixel(food.x + 1, food.y + 1, Color.Blue);
            AnsiConsole.Clear();
            AnsiConsole.Write(canvas);
            AnsiConsole.MarkupLine($"[bold white]Score:[/] {score}   [bold white]Highscore:[/] {highscore}   [bold white]Snake length:[/] {snake.Count}");
            if (playerCount == 2)
                AnsiConsole.MarkupLine($"[bold yellow]Player 2 score:[/] {score2}   [bold yellow]Snake 2 length:[/] {snake2.Count}");
        }

        static void GameLoop()
        {
            DateTime lastTick = DateTime.Now;
            snake2.Clear();
            if (playerCount == 2)
            {
                snake2.Add((width / 2 - 5, height / 2));
                dx2 = 1; dy2 = 0;
                score2 = 0;
            }
            var scoreHistory = new List<int>();
            Console.Clear(); // Only once!
            int targetFps = 60; // Higher FPS for smoother animation
            int frameTimeMs = 1000 / targetFps;
            int moveInterval = Math.Max(1, speed); // Movement interval in ms
            int moveTimer = 0;
            while (true)
            {
                var frameStart = DateTime.Now;
                if (paused)
                {
                    ShowSpectrePause();
                    Thread.Sleep(100);
                    continue;
                }
                // Ovládání hráče 1 (šipky/WASD)
                while (Console.KeyAvailable)
                {
                    var key = Console.ReadKey(true).Key;
                    if (key == ConsoleKey.UpArrow || key == ConsoleKey.W) { dx = 0; dy = -1; }
                    else if (key == ConsoleKey.DownArrow || key == ConsoleKey.S) { dx = 0; dy = 1; }
                    else if (key == ConsoleKey.LeftArrow || key == ConsoleKey.A) { dx = -1; dy = 0; }
                    else if (key == ConsoleKey.RightArrow || key == ConsoleKey.D) { dx = 1; dy = 0; }
                    // Ovládání hráče 2 (IJKL)
                    if (playerCount == 2 && gameMode == GameMode.DuelHuman)
                    {
                        if (key == ConsoleKey.I) { dx2 = 0; dy2 = -1; }
                        else if (key == ConsoleKey.K) { dx2 = 0; dy2 = 1; }
                        else if (key == ConsoleKey.J) { dx2 = -1; dy2 = 0; }
                        else if (key == ConsoleKey.L) { dx2 = 1; dy2 = 0; }
                    }
                    if (key == ConsoleKey.P) paused = !paused;
                    if (key == ConsoleKey.R) { StartGame(); return; }
                    if (key == ConsoleKey.Escape || key == ConsoleKey.Enter) { return; }
                }
                // Pohyb hadů pouze v intervalu moveInterval
                moveTimer += frameTimeMs;
                if (moveTimer >= moveInterval)
                {
                    moveTimer = 0;
                    // Pohyb hada 1
                    if (dx != 0 || dy != 0)
                    {
                        var head = snake[0];
                        var tail = snake[snake.Count - 1];
                        head.x += dx;
                        head.y += dy;
                        if (head.x < 0 || head.x >= width || head.y < 0 || head.y >= height)
                        { GameOver(); return; }
                        for (int i = 1; i < snake.Count; i++)
                            if (head.x == snake[i].x && head.y == snake[i].y)
                            { GameOver(); return; }
                        if (playerCount == 2)
                            for (int i = 0; i < snake2.Count; i++)
                                if (head.x == snake2[i].x && head.y == snake2[i].y)
                                { GameOver(); return; }
                        snake.Insert(0, head);
                        if (head.x == food.x && head.y == food.y)
                        {
                            score += foodType == FoodType.DoublePoints ? 2 : 1;
                            speed = Math.Max(10, speed - (int)foodType * 10);
                            food = GenerateFood(snake, obstacles, snake2, width, height);
                            foodType = (FoodType)rnd.Next(0, 7);
                        }
                        else
                        {
                            snake.RemoveAt(snake.Count - 1);
                        }
                    }
                    // Pohyb hada 2
                    if (playerCount == 2)
                    {
                        if (gameMode == GameMode.DuelHuman)
                        {
                            if (dx2 != 0 || dy2 != 0)
                            {
                                var head2 = snake2[0];
                                var tail2 = snake2[snake2.Count - 1];
                                head2.x += dx2;
                                head2.y += dy2;
                                if (head2.x < 0 || head2.x >= width || head2.y < 0 || head2.y >= height)
                                { GameOver(); return; }
                                for (int i = 1; i < snake2.Count; i++)
                                    if (head2.x == snake2[i].x && head2.y == snake2[i].y)
                                    { GameOver(); return; }
                                for (int i = 0; i < snake.Count; i++)
                                    if (head2.x == snake[i].x && head2.y == snake[i].y)
                                    { GameOver(); return; }
                                snake2.Insert(0, head2);
                                if (head2.x == food.x && head2.y == food.y)
                                {
                                    score2 += foodType == FoodType.DoublePoints ? 2 : 1;
                                    food = GenerateFood(snake, obstacles, snake2, width, height);
                                    foodType = (FoodType)rnd.Next(0, 7);
                                }
                                else
                                {
                                    snake2.RemoveAt(snake2.Count - 1);
                                }
                            }
                        }
                        else if (gameMode == GameMode.DuelAI)
                        {
                            // Vylepšená AI: simulace tahů dopředu, A* hledání cesty, blokace hráče
                            var head2 = snake2[0];
                            var bestMove = (dx: 0, dy: 0, score: int.MinValue);
                            var moves = new[] { (0, -1), (0, 1), (-1, 0), (1, 0) };
                            foreach (var move in moves)
                            {
                                var testHead = (head2.Item1 + move.Item1, head2.Item2 + move.Item2);
                                int moveScore = 0;
                                // Vyhýbání stěnám, tělu, překážkám
                                if (testHead.Item1 < 0 || testHead.Item1 >= width || testHead.Item2 < 0 || testHead.Item2 >= height)
                                    continue;
                                if (snake2.Contains(testHead) || snake.Contains(testHead) || obstacles.Contains(testHead))
                                    continue;
                                // A* hledání cesty k jídlu
                                int astarScore = FindPathLength(testHead, food, snake2, snake, obstacles, 3);
                                if (astarScore > 0) moveScore += 100 - astarScore * 10;
                                // Blokace hráče: pokud hráč míří na jídlo, AI se snaží blokovat
                                int playerDist = Math.Abs(snake[0].x - food.x) + Math.Abs(snake[0].y - food.y);
                                int aiDist = Math.Abs(testHead.Item1 - food.x) + Math.Abs(testHead.Item2 - food.y);
                                if (playerDist <= 3 && aiDist <= 3)
                                {
                                    if (aiDist < playerDist) moveScore += 30;
                                    else moveScore += 10;
                                }
                                // Obranný: pokud je hráč blízko, AI se snaží utéct
                                int distToPlayer = Math.Abs(testHead.Item1 - snake[0].x) + Math.Abs(testHead.Item2 - snake[0].y);
                                if (distToPlayer <= 2) moveScore -= 20;
                                // Preferuje delší vzdálenost od stěn
                                moveScore += Math.Min(testHead.Item1, width - testHead.Item1);
                                moveScore += Math.Min(testHead.Item2, height - testHead.Item2);
                                if (moveScore > bestMove.score)
                                    bestMove = (move.Item1, move.Item2, moveScore);
                            }
                            var newHead2 = (head2.Item1 + bestMove.dx, head2.Item2 + bestMove.dy);
                            if (bestMove.dx != 0 || bestMove.dy != 0)
                            {
                                snake2.Insert(0, newHead2);
                                if (newHead2.Item1 == food.x && newHead2.Item2 == food.y)
                                {
                                    score2 += foodType == FoodType.DoublePoints ? 2 : 1;
                                    food = GenerateFood(snake, obstacles, snake2, width, height);
                                    foodType = (FoodType)rnd.Next(0, 7);
                                }
                                else
                                {
                                    snake2.RemoveAt(snake2.Count - 1);
                                }
                            }
                        }
                    }
                    // Pohyb překážek
                    for (int i = 0; i < obstacles.Count; i++)
                    {
                        var obs = obstacles[i];
                        obs.x -= 1;
                        if (obs.x < 0)
                        {
                            obstacles.RemoveAt(i);
                            i--;
                        }
                    }
                }
                DrawBufferedGame();
                scoreHistory.Add(score);
                // FPS synchronizace
                var frameEnd = DateTime.Now;
                int elapsed = (int)(frameEnd - frameStart).TotalMilliseconds;
                int sleepTime = Math.Max(1, frameTimeMs - elapsed);
                Thread.Sleep(sleepTime);
            }
        }

        static void GameOver()
        {
            ShowSpectreGameOver();
        }

        static void ShowHighscores()
        {
            ShowSpectreHighscores();
            ShowSpectreMenu();
        }

        static void ShowSpectreHighscores()
        {
            AnsiConsole.Clear();
            var panel = new Panel($"[bold]{texts[selectedLanguage]["highscore"]}[/]")
                .Header("Highscores", Justify.Center)
                .Border(BoxBorder.Rounded)
                .BorderColor(new Color(255,215,0)); // Gold
            AnsiConsole.Write(panel);
            try
            {
                string[] lines = File.ReadAllLines(highscoreFile);
                var table = new Table().Border(TableBorder.Rounded).BorderColor(Color.Grey);
                table.AddColumn("#");
                table.AddColumn("Score");
                for (int i = 0; i < lines.Length; i++)
                {
                    table.AddRow($"{i + 1}", lines[i]);
                }
                AnsiConsole.Write(table);
            }
            catch (Exception ex)
            {
                LogError("Failed to show highscores.", ex);
                AnsiConsole.MarkupLine("[red]Error reading highscores.[/]");
            }
            AnsiConsole.MarkupLine($"[grey]{texts[selectedLanguage]["press_any"]}[/]");
            Console.ReadKey(true);
        }

        static void ShowSpectreGameOver()
        {
            AnsiConsole.Clear();
            var msg = string.Format(texts[selectedLanguage]["gameover1"], score);
            var panel = new Panel($"[bold red]{msg}[/]")
                .Header("Game Over", Justify.Center)
                .Border(BoxBorder.Rounded)
                .BorderColor(new Color(255,0,0)); // Red
            AnsiConsole.Write(panel);
            if (score > highscore)
            {
                highscore = score;
                SaveHighscore();
                AnsiConsole.MarkupLine($"[bold green]{texts[selectedLanguage]["newrecord"]}[/]");
            }
            AnsiConsole.MarkupLine($"[grey]{texts[selectedLanguage]["press_any"]}[/]");
            Console.ReadKey(true);
            ShowSpectreMenu();
        }

        static void DrawBorder()
        {
            for (int x = 0; x <= width; x++)
            {
                Console.SetCursorPosition(x, 0);
                Console.Write("█");
                Console.SetCursorPosition(x, height + 1);
                Console.Write("█");
            }
            for (int y = 0; y <= height + 1; y++)
            {
                Console.SetCursorPosition(0, y);
                Console.Write("█");
                Console.SetCursorPosition(width + 1, y);
                Console.Write("█");
            }
        }

        static void DrawSnake()
        {
            foreach (var part in snake)
            {
                Console.SetCursorPosition(part.x + 1, part.y + 1);
                Console.Write("■");
            }
        }

        static void DrawSnake2()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            foreach (var part in snake2)
            {
                Console.SetCursorPosition(part.Item1 + 1, part.Item2 + 1);
                Console.Write("□");
            }
            Console.ResetColor();
        }

        static void DrawFood()
        {
            Console.SetCursorPosition(food.x + 1, food.y + 1);
            Console.Write(foodType == FoodType.DoublePoints ? "♦" : "●");
        }

        static void DrawObstacles()
        {
            foreach (var obs in obstacles)
            {
                Console.SetCursorPosition(obs.x + 1, obs.y + 1);
                Console.Write("■");
            }
        }

        static void DrawUI()
        {
            Console.SetCursorPosition(0, height + 3);
            Console.Write(texts[selectedLanguage]["score"], score, highscore, snake.Count);
            if (playerCount == 2)
                Console.Write("   " + texts[selectedLanguage]["score2"], score2, snake2.Count);
            Console.SetCursorPosition(0, height + 4);
            Console.WriteLine(texts[selectedLanguage]["pause"]);
            Console.SetCursorPosition(0, height + 5);
            Console.WriteLine(texts[selectedLanguage]["restart"]);
        }

        static int ReadIntInput(string prompt, int min, int max)
        {
            int value;
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();
                if (int.TryParse(input, out value) && value >= min && value <= max)
                    return value;
                Console.WriteLine($"Invalid input! Enter a number between {min} and {max}.");
            }
        }

        static void ChangeLevel()
        {
            Console.Clear();
            Console.WriteLine(texts[selectedLanguage]["level"], selectedLevel);
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine($"{i} - {i * 10} {texts[selectedLanguage]["points"]} (speed {11 - i})");
            }
            Console.WriteLine(texts[selectedLanguage]["press_any"]);
            ConsoleKeyInfo key = Console.ReadKey(true);
            if (char.IsDigit(key.KeyChar))
            {
                int level = int.Parse(key.KeyChar.ToString());
                if (level >= 1 && level <= 5)
                {
                    selectedLevel = level;
                    speed = 110 - level * 10;
                }
            }
            Main();
        }

        static void ChangePlayers()
        {
            Console.Clear();
            Console.WriteLine(texts[selectedLanguage]["players"], playerCount);
            Console.WriteLine("1 - 1 hráč");
            Console.WriteLine("2 - 2 hráči");
            Console.WriteLine(texts[selectedLanguage]["press_any"]);
            ConsoleKeyInfo key = Console.ReadKey(true);
            if (key.KeyChar == '1')
                playerCount = 1;
            else if (key.KeyChar == '2')
                playerCount = 2;
            Main();
        }

        static void ToggleGameLog()
        {
            gameLogEnabled = !gameLogEnabled;
            Console.Clear();
            Console.WriteLine(texts[selectedLanguage]["log"], gameLogEnabled ? texts[selectedLanguage]["log_on"] : texts[selectedLanguage]["log_off"]);
            Console.WriteLine(texts[selectedLanguage]["press_any"]);
            Console.ReadKey(true);
            Main();
        }

        static void ChangeLanguage()
        {
            Console.Clear();
            Console.WriteLine(texts[selectedLanguage]["lang"], selectedLanguage.ToUpper());
            Console.WriteLine(texts[selectedLanguage]["press_any"]);
            ConsoleKeyInfo key = Console.ReadKey(true);
            string lang = key.KeyChar.ToString().ToLower();
            if (Array.Exists(supportedLanguages, l => l == lang))
                selectedLanguage = lang;
            Main();
        }

        static void HowToPlay()
        {
            Console.Clear();
            Console.WriteLine(texts[selectedLanguage]["howto_text"]);
            Console.WriteLine(texts[selectedLanguage]["howto_text2"]);
            Console.WriteLine(texts[selectedLanguage]["press_any"]);
            Console.ReadKey(true);
            Main();
        }

        static void ShowMenu()
        {
            string lastInput = null;
            string errorMsg = null;
            while (true)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("============================");
                Console.WriteLine(texts[selectedLanguage]["menu_title"]);
                Console.WriteLine("============================");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("      " + texts[selectedLanguage]["devbrain"]);
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine();
                Console.WriteLine(texts[selectedLanguage]["start"]);
                Console.WriteLine(texts[selectedLanguage]["highscore"]);
                Console.WriteLine("TOP 5:");
                if (File.Exists(highscoreFile))
                {
                    var lines = File.ReadAllLines(highscoreFile);
                    for (int i = 0; i < Math.Min(5, lines.Length); i++)
                        Console.WriteLine($"{i + 1}. {lines[i]}");
                }
                Console.WriteLine(texts[selectedLanguage]["level"], selectedLevel);
                Console.WriteLine(texts[selectedLanguage]["players"], playerCount);
                Console.WriteLine(texts[selectedLanguage]["log"], gameLogEnabled ? texts[selectedLanguage]["log_on"] : texts[selectedLanguage]["log_off"]);
                Console.WriteLine(texts[selectedLanguage]["lang"], selectedLanguage.ToUpper());
                Console.WriteLine(texts[selectedLanguage]["howto"]);
                Console.WriteLine("9 - Herní mód (Single/Duel hráči/Duel AI)");
                Console.WriteLine(texts[selectedLanguage]["exit"]);
                Console.ResetColor();
                if (lastInput != null)
                {
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine($"Zadal jsi: '{lastInput}'");
                    Console.ResetColor();
                }
                if (errorMsg != null)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(errorMsg);
                    Console.ResetColor();
                }
                Console.Write(texts[selectedLanguage]["choice_prompt"]);
                string input = Console.ReadLine();
                lastInput = input;
                errorMsg = null;
                bool changed = false;
                if (input == "1")
                    StartGame();
                else if (input == "2")
                    ShowHighscores();
                else if (input == "3")
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("============================");
                    Console.WriteLine(texts[selectedLanguage]["level"], selectedLevel);
                    Console.WriteLine("============================");
                    Console.ResetColor();
                    Console.WriteLine("1 - Lehká");
                    Console.WriteLine("2 - Střední");
                    Console.WriteLine("3 - Těžká");
                    int lvlIdx = ReadIntInput(texts[selectedLanguage]["choice_prompt"], 1, 3);
                    selectedLevel = lvlIdx;
                    SaveHighscore();
                    continue;
                }
                else if (input == "4")
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("============================");
                    Console.WriteLine(texts[selectedLanguage]["players"], playerCount);
                    Console.WriteLine("============================");
                    Console.ResetColor();
                    Console.WriteLine("1 - 1 hráč");
                    Console.WriteLine("2 - 2 hráči");
                    int pInput = ReadIntInput(texts[selectedLanguage]["choice_prompt"], 1, 2);
                    playerCount = pInput;
                    SaveHighscore();
                    continue;
                }
                else if (input == "5")
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("============================");
                    Console.WriteLine(texts[selectedLanguage]["log"], gameLogEnabled ? texts[selectedLanguage]["log_on"] : texts[selectedLanguage]["log_off"]);
                    Console.WriteLine("============================");
                    Console.ResetColor();
                    Console.WriteLine("1 - Zapnuto");
                    Console.WriteLine("2 - Vypnuto");
                    Console.Write(texts[selectedLanguage]["choice_prompt"]);
                    string logInput = Console.ReadLine();
                    if (logInput == "1") gameLogEnabled = true;
                    else if (logInput == "2") gameLogEnabled = false;
                    SaveHighscore();
                    continue;
                }
                else if (input == "6")
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("============================");
                    Console.WriteLine(texts[selectedLanguage]["lang"], selectedLanguage.ToUpper());
                    Console.WriteLine("============================");
                    Console.ResetColor();
                    for (int i = 0; i < supportedLanguages.Length; i++)
                    {
                        Console.WriteLine($"{i + 1} - {supportedLanguages[i].ToUpper()}");
                    }
                    Console.Write(texts[selectedLanguage]["choice_prompt"]);
                    string langInput = Console.ReadLine();
                    if (int.TryParse(langInput, out int langIdx) && langIdx >= 1 && langIdx <= supportedLanguages.Length)
                    {
                        selectedLanguage = supportedLanguages[langIdx - 1];
                        SaveHighscore();
                    }
                    continue;
                }
                else if (input == "7")
                {
                    HowToPlay();
                    continue;
                }
                else if (input == "8")
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("============================");
                    Console.WriteLine($"Barvy (aktuální: Default/Retro/HighContrast)");
                    Console.WriteLine("============================");
                    Console.ResetColor();
                    Console.WriteLine("1 - Default");
                    Console.WriteLine("2 - Retro");
                    Console.WriteLine("3 - HighContrast");
                    int colorIdx = ReadIntInput(texts[selectedLanguage]["choice_prompt"], 1, 3);
                    colorScheme = colorIdx - 1;
                    SaveHighscore();
                    continue;
                }
                else if (input == "9")
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("============================");
                    Console.WriteLine($"Herní mód (aktuální: {(playerCount == 1 ? "Single" : "Duel")})");
                    Console.WriteLine("============================");
                    Console.ResetColor();
                    Console.WriteLine("1 - Single");
                    Console.WriteLine("2 - Duel hráči");
                    Console.WriteLine("3 - Duel AI");
                    int modeIdx = ReadIntInput(texts[selectedLanguage]["choice_prompt"], 1, 3);
                    gameMode = (GameMode)(modeIdx - 1);
                    playerCount = gameMode == GameMode.Single ? 1 : 2;
                    SaveHighscore();
                    continue;
                }
                else if (input?.ToLower() == "esc" || input == "")
                    Environment.Exit(0);
                else
                    errorMsg = "Neplatná volba! Zadej číslo z nabídky.";
                if (changed) SaveHighscore();
            }
        }

        static void Main()
        {
            LoadHighscore();
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            ShowSpectreMenu();
        }

        // Pomocná funkce: A* hledání cesty k cíli, vrací délku cesty nebo -1
        public static int FindPathLength((int x, int y) start, (int x, int y) goal, List<(int x, int y)> snake2, List<(int x, int y)> snake, List<(int x, int y)> obstacles, int maxDepth)
        {
            var open = new Queue<((int x, int y) pos, int depth)>();
            var visited = new HashSet<(int x, int y)>();
            open.Enqueue((start, 0));
            while (open.Count > 0)
            {
                var (pos, depth) = open.Dequeue();
                if (pos == goal) return depth;
                if (depth >= maxDepth) continue;
                foreach (var move in new[] { (0, -1), (0, 1), (-1, 0), (1, 0) })
                {
                    var next = (pos.x + move.Item1, pos.y + move.Item2);
                    if (next.Item1 < 0 || next.Item1 >= width || next.Item2 < 0 || next.Item2 >= height) continue;
                    if (visited.Contains(next)) continue;
                    if (snake2.Contains(next) || snake.Contains(next) || obstacles.Contains(next)) continue;
                    visited.Add(next);
                    open.Enqueue((next, depth + 1));
                }
            }
            return -1;
        }

        static void ShowSpectreMenu()
        {
            while (true)
            {
                AnsiConsole.Clear();
                var panel = new Panel($"[bold cyan]{texts[selectedLanguage]["menu_title"]}[/]\n[white]{texts[selectedLanguage]["devbrain"]}[/]")
                    .Header("Snake Evolution", Justify.Center)
                    .Border(BoxBorder.Rounded)
                    .BorderColor(new Color(0,255,255)); // Cyan
                AnsiConsole.Write(panel);
                var table = new Table().Border(TableBorder.Rounded).BorderColor(Color.Grey);
                table.AddColumn("[bold]#[/]");
                table.AddColumn("[bold]Option[/]");
                table.AddRow("1", texts[selectedLanguage]["start"]);
                table.AddRow("2", texts[selectedLanguage]["highscore"]);
                table.AddRow("3", string.Format(texts[selectedLanguage]["level"], selectedLevel));
                table.AddRow("4", string.Format(texts[selectedLanguage]["players"], playerCount));
                table.AddRow("5", string.Format(texts[selectedLanguage]["log"], gameLogEnabled ? texts[selectedLanguage]["log_on"] : texts[selectedLanguage]["log_off"]));
                table.AddRow("6", string.Format(texts[selectedLanguage]["lang"], selectedLanguage.ToUpper()));
                table.AddRow("7", texts[selectedLanguage]["howto"]);
                table.AddRow("8", $"Barvy (aktuální: {colorSchemeNames[colorScheme]})");
                table.AddRow("9", $"Herní mód (aktuální: {(playerCount == 1 ? "Single" : (gameMode == GameMode.DuelHuman ? "Duel hráči" : "Duel AI"))})");
                table.AddRow("Esc/Enter", texts[selectedLanguage]["exit"]);
                AnsiConsole.Write(table);
                if (File.Exists(highscoreFile))
                {
                    var lines = File.ReadAllLines(highscoreFile);
                    var hsTable = new Table().Border(TableBorder.Rounded).BorderColor(Color.Grey);
                    hsTable.AddColumn("Top 5");
                    for (int i = 0; i < Math.Min(5, lines.Length); i++)
                        hsTable.AddRow($"{i + 1}. {lines[i]}");
                    AnsiConsole.Write(hsTable);
                }
                var input = AnsiConsole.Prompt(new TextPrompt<string>(texts[selectedLanguage]["choice_prompt"]).AllowEmpty());
                if (input == "1") StartGame();
                else if (input == "2") ShowHighscores();
                else if (input == "3")
                {
                    selectedLevel = AnsiConsole.Prompt(new SelectionPrompt<int>().Title("Vyber úroveň:").AddChoices(1, 2, 3));
                    SaveHighscore();
                }
                else if (input == "4")
                {
                    playerCount = AnsiConsole.Prompt(new SelectionPrompt<int>().Title("Počet hráčů:").AddChoices(1, 2));
                    SaveHighscore();
                }
                else if (input == "5")
                {
                    gameLogEnabled = AnsiConsole.Prompt(new SelectionPrompt<bool>().Title("Herní log:").AddChoices(true, false));
                    SaveHighscore();
                }
                else if (input == "6")
                {
                    var langIdx = AnsiConsole.Prompt(new SelectionPrompt<int>().Title("Jazyk:").AddChoices(1,2,3,4,5,6));
                    selectedLanguage = supportedLanguages[langIdx - 1];
                    SaveHighscore();
                }
                else if (input == "7")
                {
                    ShowSpectreHowToPlay();
                }
                else if (input == "8")
                {
                    colorScheme = AnsiConsole.Prompt(new SelectionPrompt<int>().Title("Barvy:").AddChoices(1,2,3)) - 1;
                    SaveHighscore();
                }
                else if (input == "9")
                {
                    var modeIdx = AnsiConsole.Prompt(new SelectionPrompt<int>().Title("Herní mód:").AddChoices(1,2,3));
                    gameMode = (GameMode)(modeIdx - 1);
                    playerCount = gameMode == GameMode.Single ? 1 : 2;
                    SaveHighscore();
                }
                else if (string.IsNullOrEmpty(input) || input.ToLower() == "esc")
                    Environment.Exit(0);
            }
        }

        static void ShowSpectreHowToPlay()
        {
            AnsiConsole.Clear();
            var panel = new Panel($"[bold]{texts[selectedLanguage]["howto_text"]}[/]\n{texts[selectedLanguage]["howto_text2"]}")
                .Header("Jak hrát", Justify.Center)
                .Border(BoxBorder.Rounded)
                .BorderColor(new Color(0,255,0)); // Green
            AnsiConsole.Write(panel);
            AnsiConsole.MarkupLine($"[grey]{texts[selectedLanguage]["press_any"]}[/]");
            Console.ReadKey(true);
        }
    }
}
